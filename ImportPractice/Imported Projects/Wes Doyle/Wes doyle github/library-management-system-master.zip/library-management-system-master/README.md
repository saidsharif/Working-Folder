# LightLib Library Management System

[![Build Status](https://travis-ci.org/wesdoyle/library-management-system.svg?branch=master)](https://travis-ci.org/wesdoyle/library-management-system) [![Codecov branch](https://img.shields.io/codecov/c/github/wesdoyle/library-management-system/master.svg?style=flat)](https://codecov.io/gh/wesdoyle/library-management-system)



A lightweight library management system built in ASP.NET Core 2.0

I created a YouTube series when I started this application: [YouTube link](https://www.youtube.com/watch?v=WTVcLFTgDqs)
The application has since been migrated to dotnet core 2.0.
