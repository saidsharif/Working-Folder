﻿using System;

namespace Advantage.API.Demo.Models
{
    public class ServerMessage
    {
        public int Id { get; set; }
        public string Payload { get; set; }
        // DateTime Sent { get; set; }
    }
}
