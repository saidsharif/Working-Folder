﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp99Problems //Rotate a list N places to the left
{
    public class Problem_19
    {
        public static void Execute(string[] args)
        {


        }
    }
}
