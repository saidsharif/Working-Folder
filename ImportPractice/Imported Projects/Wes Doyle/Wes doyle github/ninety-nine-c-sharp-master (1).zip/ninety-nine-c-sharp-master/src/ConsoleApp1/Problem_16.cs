﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp99Problems //Drop every Nth element from a list
{
    public class Problem_16
    {
        public static void Execute(string[] args)
        {


        }
    }
}
