﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp99Problems //Split a list into two parts
{
    public class Problem_17
    {
        public static void Execute(string[] args)
        {


        }
    }
}
