﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp99Problems //Run-length encoding of a list (direct solution)
{
    public class Problem_13
    {
        public static void Execute(string[] args)
        {
            Console.WriteLine("Problem not complete yet");
        }
    }
}
