﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSharp99Problems //Extract a slice from a list
{
    public class Problem_18
    {
        public static void Execute(string[] args)
        {


        }
    }
}
