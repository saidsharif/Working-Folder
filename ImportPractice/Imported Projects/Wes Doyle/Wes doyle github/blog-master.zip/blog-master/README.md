# Blog 

This is my personal blog.

[https://wesdoyle.net](https://wesdoyle.net)

## Notes

If you're interested, I've built this iteration of the blog using Gridsome, which is a JAMstack Vue.js static site generator.  My blog posts and reading notes are written in markdown.  The app is deployed using Netlify.

## Build
```
gridsome build
```
