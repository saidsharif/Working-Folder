<template>
  <div id="footerContainer">
    <div class="footer-links">
      <a target="_blank" href="/sitemap.xml">Sitemap</a>
      <a target="_blank" href="/feed.xml">RSS Feed</a>
    </div>
  </div>
</template>

<script>
  export default {
    name: "BlogFooter"
  }
</script>

<style scoped lang="scss">
  #footerContainer {

  }
</style>
