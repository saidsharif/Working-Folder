---
title: "48 Laws of Power"
slug: "48-laws"
author: "Robert Greene"
tags: "psychology"
date: 2019-08-19
---
