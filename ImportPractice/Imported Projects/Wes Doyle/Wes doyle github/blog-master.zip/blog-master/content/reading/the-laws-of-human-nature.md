---
title: "The Laws of Human Nature"
author: "Robert Greene"
tags: "psychology, leadership"
slug: "laws-human-nature"
date: 2019-08-19
---

