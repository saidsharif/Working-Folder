---

title: "The Death of Expertise: The Campaign Against Established Knowledge and Why it Matters"
author: "Tom Nichols"
slug: "death-of-expertise"
tags: "education, expertise"
date: 2019-08-19
---


