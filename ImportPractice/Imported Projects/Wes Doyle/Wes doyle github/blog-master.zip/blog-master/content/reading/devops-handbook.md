---
title: "The DevOps Handbook: How to Create World-Class Agility, Reliability, and Security in Technology Organizations"
author: "Gene Kim, Patrick DuBois, John Willis, Jez Humble"
slug: "devops-handbook"
tags: "devops, engineering, leadership"
date: 2019-08-19
---
