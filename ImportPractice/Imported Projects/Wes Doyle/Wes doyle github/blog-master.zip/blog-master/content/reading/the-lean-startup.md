---
title: "The Lean Startup"
author: "Eric Ries"
tags: "leadership, engineering"
slug: "lean-startup"
date: 2019-08-19
---


