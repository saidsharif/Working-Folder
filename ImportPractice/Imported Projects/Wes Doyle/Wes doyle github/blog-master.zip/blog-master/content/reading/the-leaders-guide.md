---
title: "The Leader's Guide"
author: "Eric Ries"
tags: "leadership, engineering"
slug: "leaders-guide"
date: 2019-08-19
---
