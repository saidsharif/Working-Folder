---
title: "Dress Your Family in Corduroy and Denim"
slug: "dress-your-fam"
author: "David Sedaris"
tags: "essays"
date: 2020-02-01
---
