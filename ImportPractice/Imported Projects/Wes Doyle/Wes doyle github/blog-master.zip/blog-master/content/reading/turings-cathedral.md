---
title: "Turing's Cathedral: The Origins of the Digital Universe"
author: "George Dyson"
tags: "computer science, history, turing"
slug: "turings-cathedral"
date: 2019-08-19
---


