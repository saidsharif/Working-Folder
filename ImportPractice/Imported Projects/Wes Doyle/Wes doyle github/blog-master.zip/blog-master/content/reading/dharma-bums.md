---
title: "The Dharma Bums"
slug: "dharma-bums"
author: "Jack Kerouac"
tags: "beat literature"
date: 2020-03-01
---
