---
title: "Collected Fictions"
author: "Jorge Luis Borges"
slug: "collected-fictions"
tags: "short stories, argentina, complexity"
date: 2019-08-19
---
