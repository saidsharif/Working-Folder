---
title: "A Mind at Play: How Claude Shannon Invented the Information Age"
slug: "mind-at-play"
author: "Jimmy Soni, Rob Goodman"
tags: "claude shannon, biography, computer science"
date: 2019-08-19
---


