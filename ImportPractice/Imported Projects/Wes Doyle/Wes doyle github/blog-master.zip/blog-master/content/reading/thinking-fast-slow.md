---
title: "Thinking, Fast and Slow"
slug: "thinking-fast-slow"
author: "Daniel Kahneman"
tags: "psychology"
date: 2020-07-01
---
