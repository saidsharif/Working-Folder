---
title: "Rendezvous with Rama"
author: "Arthur C. Clarke"
tags: "science fiction"
slug: "rama"
date: 2020-01-19
---

I don't usually get into science fiction, but I read this book on a
recommendation around the holidays, and I thought it was pretty fun.
I love the concept of the enormous cylindrical craft serving as an artificial
planet imagined in the book.


