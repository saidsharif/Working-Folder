---
title: "To Build a Fire"
slug: "to-build-a-fire"
author: "Jack London"
tags: "short story"
date: 2020-06-01
---
