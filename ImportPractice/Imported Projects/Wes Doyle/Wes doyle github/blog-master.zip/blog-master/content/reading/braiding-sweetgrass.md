---
title: "Braiding Sweetgrass: Indigenous Wisdom, Scientific Knowledge, and the Teaching of Plants"
author: "Robin Wall Kimmerer"
slug: "braiding-sweetgrass"
tags: "botany, ecology, society, indegenous wisdom"
date: 2019-08-19
---
