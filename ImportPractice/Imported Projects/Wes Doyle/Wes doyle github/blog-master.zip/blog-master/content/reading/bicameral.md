---
title: "The Origin of Consciousness in the Breakdown of the Bicameral Mind"
slug: "bicameral"
author: "Julian Jaynes"
tags: "consciousness"
date: 2020-07-12
---
