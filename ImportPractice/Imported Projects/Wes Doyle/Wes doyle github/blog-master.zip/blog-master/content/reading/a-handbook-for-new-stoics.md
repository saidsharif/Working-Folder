---
title: "A Handbook for New Stoics"
slug: "handbook-stoics"
author: "Pigliucci, Lopez"
tags: "philosophy, psychology"
date: 2019-08-19
---

