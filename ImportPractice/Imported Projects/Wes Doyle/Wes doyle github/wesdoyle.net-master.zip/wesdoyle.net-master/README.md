# wesdoyle.net
my personal static webpage
